package amoba;

public enum Jatekos {
    FEKETE, FEHER
}
